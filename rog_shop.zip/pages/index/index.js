// index.js
Page({
  data:{
      // 推荐商品数据
      goodsList:[
        {
          id: 100,
          title: "rog主机",
          price: 841499.00,
          thumb: "/rog-img/主机.jpg"
        },
        {
          id: 101,
          title: "rog主版",
          price: 1995454.00,
          thumb: "/rog-img/主板.webp"
        },
        {
          id: 102,
          title: "rog入耳式耳机",
          price: 3485840.00,
          thumb: "/rog-img/入耳式耳机.jpg"
        },
        {
          id: 104,
          title: "rog初音未来",
          price: 199999.00,
          thumb: "/rog-img/初音未来主板.png"
        },
        {
          id: 103,
          title: "rog太阳神",
          price: 199999.00,
          thumb: "/rog-img/太阳神.png"
        },
        {
          id: 106,
          title: "rog游戏手机",
          price: 199999.00,
          thumb: "/rog-img/手机.webp"
        },{
          id: 107,
          title: "rog掌机",
          price: 154952325433665,
          thumb: "/rog-img/掌机.png"
        },{
          id: 108,
          title: "rog RTX3090 Ti",
          price: 1549532253423665,
          thumb: "/rog-img/显卡.png"
        },{
          id: 109,
          title: "rog RTX4090",
          price: 154953454323665,
          thumb: "/rog-img/显卡.webp"
        },{
          id: 105,
          title: "rog显示器",
          price: 154952645643665,
          thumb: "/rog-img/显示器.jpg"
        },{
          id: 202,
          title: "rog 8K 显示器",
          price: 1549465675523665,
          thumb: "/rog-img/显示器.webp"
        },{
          id: 203,
          title: "rog 游戏手机",
          price: 15495654635623665,
          thumb: "/rog-img/游戏手机.png"
        },{
          id: 204,
          title: "rog枪神7",
          price: 15492322345523665,
          thumb: "/rog-img/笔记本.png"
        },{
          id: 201,
          title: "rog笔记本",
          price: 1549423432523665,
          thumb: "/rog-img/笔记本.webp"
        },{
          id: 205,
          title: "rog耳机",
          price: 1549542342323665,
          thumb: "/rog-img/耳机.jpg"
        },{
          id: 206,
          title: "rog键盘",
          price: 15492344233665,
          thumb: "/rog-img/键盘 (2).jpg"
        },{
          id: 207,
          title: "jp",
          price: 1233665,
          thumb: "/rog-img/键盘.jpg"
        },{
          id: 208,
          title: "rog鼠标",
          price: 1543432432665,
          thumb: "/rog-img/鼠标.jpg"
        }
        /*
        {
          id: ,
          title: "",
          price: ,
          thumb: "/rog-img"
        }
        */
      ]
  }
})
