import success from './result/success'
import fail from './result/fail'

export default {
    ...success,
    ...fail
  }
