import settings from './account/settings'

export default {
    ...settings
  }
