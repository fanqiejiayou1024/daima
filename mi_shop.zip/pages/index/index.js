// index.js
Page({
  data:{
      // 推荐商品数据
      goodsList:[
        {
          id: 102,
          title: "Xiaomi 15 SPro",
          price: 841499.00,
          thumb: "https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/ccb333fb5e8dae8ea011e8e968b05627.png?thumb=1&w=160&h=110&f=webp&q=90"
        },
        {
          id: 104,
          title: "Xiaomi MIX Flip",
          price: 1995454.00,
          thumb: "https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/8059e5c1decb3331d95c65b28e016ef5.png?thumb=1&w=160&h=110&f=webp&q=90"
        },
        {
          id: 103,
          title: "Xiaomi 17 Pro",
          price: 3485840.00,
          thumb: "https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1758612755.22399850.png"
        },
        {
          id: 104,
          title: "Xiaomi Pad 8 Pro",
          price: 199999.00,
          thumb: "https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1758276214.25323975.png"
        },
        {
          id: 101,
          title: "Xiaomi MIX Alpha",
          price: 199999.00,
          thumb: "https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1569297737.97669352.jpg"
        },
        {
          id: 106,
          title: "Xiaomi SU7 Ultra定制版",
          price: 199999.00,
          thumb: "https://img.v.mifile.cn/nr-upload-car/CD5F84CEE7853099C4C403C7C3FEBE6D_1758771452198.png?x-fds-process=image/resize,f_webp,q_100"
        }
      ]
  }
})
